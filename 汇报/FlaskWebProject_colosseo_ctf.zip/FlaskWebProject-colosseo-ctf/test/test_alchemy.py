from sqlalchemy.ext.automap import automap_base
from sqlalchemy import create_engine, Table, MetaData
from sqlalchemy.orm import Session
from sqlalchemy.orm import scoped_session,sessionmaker


Base = automap_base()

class User(Base):
    __tablename__ = 'general_users'

    def __init__(self):
        pass


    def to_dict(self):
        d = {}
        d['sequence'] = self.sequence
        d['name'] = self.name

        return d
    """description of class"""

# reflect
engine_u = create_engine('mysql+mysqlconnector://remoteuser:password@192.168.80.143:3306/users',
echo = True)
Base.prepare(engine_u, reflect=True)
#注册机制
session_factory = sessionmaker(bind=engine_u)
Session = scoped_session(session_factory)
session_test = Session()


#test
u1 = session_test.query(User).first()
print (u1.to_dict())