import mysql.connector
mydb_questions = mysql.connector.connect(
    host="192.168.80.141",
    user="remoteuser",
    passwd="password"
    )

print(mydb_questions)